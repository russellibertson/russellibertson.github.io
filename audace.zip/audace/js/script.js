$("body").children().each(function() {
  document.body.innerHTML = document.body.innerHTML.replace(/\u2028/g, ' ');
});

$('.catalog__choice h5').on('click', function(){
$(this).toggleClass('in');
$('.catalog__choice h5').not(this).removeClass('in').next()});

$('.header__hamburger').on('click', function(){
$('html').toggleClass('close');
$('.header__hamburger').not(this).removeClass('close').next()});

$(document).ready(function() {
  //прикрепляем клик по заголовкам acc-head
  $('.header__moblist1-list .hide__menu-panel').on('click', f_acc2);
});
 
function f_acc2(){
  $('.header__moblist1-list .submenu3').not($(this).next()).slideUp();
  $(this).next().slideToggle();
}

$(".article-seo__info").addClass("container-closed1");
// click event
$(".trigger1").click( function() {
      $(".article-seo__info").toggleClass("container-closed1");
      $(this).toggleClass('treverse1');
      $(this).html($(this).html() == 'Показать еще' ? 'Свернуть' : 'Показать еще');
});

$(".article-temp__info").addClass("container-closed2");
// click event
$(".trigger2").click( function() {
      $(".article-temp__info").toggleClass("container-closed2");
      $(this).toggleClass('treverse2');
      $(this).html($(this).html() == 'Показать еще' ? 'Свернуть' : 'Показать еще');
});

$(".contract").addClass("container-closed3");
// click event
$(".trigger3").click( function() {
      $(".contract").toggleClass("container-closed3");
      $(this).toggleClass('treverse3');
      $(this).html($(this).html() == 'Показать еще' ? 'Свернуть' : 'Показать еще');
});

$(".services-home .container").addClass("container-closed4");
// click event
$(".trigger4").click( function() {
      $(".services-home .container").toggleClass("container-closed4");
      $(this).toggleClass('treverse4');
      $(this).html($(this).html() == 'Показать еще' ? 'Свернуть' : 'Показать еще');
});

$(".user__description-item").addClass("container-closed5");
// click event
$(".trigger5").click( function() {
      $(".user__description-item").toggleClass("container-closed5");
      $(this).toggleClass('treverse5');
      $(this).html($(this).html() == 'Раскрыть полностью' ? 'Свернуть' : 'Раскрыть полностью');
});

$('.instructions__panel-heading').click(function(){
  $(this).next(".instructions__panel-collapse").slideToggle();
  $(this).closest(".instructions__panel").siblings().find('.instructions__panel-collapse').slideUp();
});

$( ".catalog-link, .header__category-list" ).hover(
  function() {
    $('main').addClass("bg-hover");
  }, function() {
    $('main').removeClass("bg-hover");
  }
);

$('.header__mobile-panel').click(function () {
	$('.header__moblist1').toggle();
	$('.header__moblist2').hide();
	$('.header__moblist3').hide();
  $('.header__moblist4').hide();
  $('.header__moblist5').hide();
});

$('.header__hamburger').click(function () {
	$('.header__moblist2').toggle();
	$('.header__moblist1').hide();
	$('.header__moblist3').hide();
  $('.header__moblist4').hide();
  $('.header__moblist5').hide();
});

$('.header__mobile-cabinet').click(function () {
	$('.header__moblist3').toggle();
	$('.header__moblist1').hide();
	$('.header__moblist2').hide();
  $('.header__moblist4').hide();
  $('.header__moblist5').hide();
});

$('.header__mobile-panel2').click(function () {
  $('.header__moblist4').toggle();
  $('.header__moblist1').hide();
  $('.header__moblist2').hide();
  $('.header__moblist3').hide();
  $('.header__moblist5').hide();
});

$('.banner__info-btn, .header__search-create, .header__specialist-link, .auth__acc, .auth__miss').magnificPopup({
  type: 'inline',
  removalDelay: 500,
  fixedContentPos: true,
  fixedBgPos: true,
  mainClass: 'my-mfp-zoom-in',
  closeMarkup: '<button class="mfp-close roundlink">\
  <img class="mfp-close reel-btn-off" src="/img/cancel.png"/>\
  </button>',
  closeBtnInside: true,
  callbacks: {
    beforeOpen: function() {
      startWindowScroll = $(window).scrollTop();
      $('html').addClass('mfp-helper');
    },
    close: function() {
      $('html').removeClass('mfp-helper');
      $(window).scrollTop(startWindowScroll);
    }
  }
});

$('.services-home__item a, .product-fixed__download, .services-footer-link a').magnificPopup({
  items: {
    src: '#services-modal'
  },
  type: 'inline',
  removalDelay: 500,
  fixedContentPos: true,
  fixedBgPos: true,
  mainClass: 'my-mfp-zoom-in',
  closeMarkup: '<button class="mfp-close roundlink">\
  <img class="mfp-close reel-btn-off" src="/img/cancel.png"/>\
  </button>',
  callbacks: {
    beforeOpen: function() {
      startWindowScroll = $(window).scrollTop();
      $('html').addClass('mfp-helper');
    },
    close: function() {
      $('html').removeClass('mfp-helper');
      $(window).scrollTop(startWindowScroll);
    }
  }
});



function closePopup() {
  $.magnificPopup.close();
}

$(document).ready(function () {
  setTimeout(function() {
   if ($('#default').length) {
     $.magnificPopup.open({
      items: {
          src: '#default' 
      },
      type: 'inline',
      removalDelay: 500,
      fixedContentPos: true,
      fixedBgPos: true,
      mainClass: 'my-mfp-zoom-in',
      closeMarkup: '<button class="mfp-close roundlink">\
      <img class="mfp-close reel-btn-off" src="img/cancel.png"/>\
      </button>',
      callbacks: {
        beforeOpen: function() {
          startWindowScroll = $(window).scrollTop();
          $('html').addClass('mfp-helper');
        },
        close: function() {
          $('html').removeClass('mfp-helper');
          $(window).scrollTop(startWindowScroll);
        }
      }
      });
     }
   }, 1000);
});

function dropdown() {
  document.getElementById("dropdown-menu1").classList.toggle("show");
}

dropdown.onclick = function(event) {
  if (!event.target.matches('.header__category-panel')) {
    var dropdowns = document.getElementsByClassName("header__category-nav");
    var i;
    for (i = 0; i < dropdowns.length; i++) {
      var openDropdown = dropdowns[i];
      if (openDropdown.classList.contains('show')) {
        openDropdown.classList.remove('show');
      }
    }
  }
}

// Прелоадер
window.onload=function(){   
  setTimeout(function(){
    $(".preloader").fadeOut(500);    
  }, 500);
  
  $('[rel="nofollow"]').parent().hide();
  $('.cbalink').hide();
}

$(document).ready(function(){
	$(".header__category-item").hover(function (){
		$("body").toggleClass("bg-hover");
	});

	// Открыть Поиск на мобильных
	$(".mobile-header__search, .search-close").click(function (){
		$("body").toggleClass("search-active");
	});

	// Открыть Меню на мобильных
	$(".mobile-header__menu, .overlay").click(function (){
		$("body").toggleClass("mobile-menu-active");
	});

	// Работа меню на мобильных
	$(".catalog__list li span.sub-menu-toggle").bind('click', function (){
		var item = $(this).parent();

		item.parent().find("li").not(item).removeClass("active");
		item.toggleClass("active");

		item.parent().parent().find("li.multi-level-menu").not(item).find("ul").slideUp(500);
		item.parent().parent().find("li.mega-alphabet-menu").not(item).find("> div").slideUp(500);
	

		item.find(".mega-menu").slideToggle(500);	
		item.find("> ul").slideToggle(500);	

		return false;
	});
});

$('#prev-rev').on('click', function() {
  $('.revievs-home__list').animate({
    scrollLeft: '-=244'
  }, 300, 'swing');
});

$('#next-rev').on('click', function() {
  $('.revievs-home__list').animate({
    scrollLeft: '+=249'
  }, 300, 'swing');
});

$('instructions__main.active .instructions__panel-heading').click(function(){
  $(this).next(".instructions__panel-collapse").slideToggle();
  $(this).closest(".instructions__panel").siblings().find('.instructions__panel-collapse').slideUp();
});

$(document).ready(function (){
  $(".instructions.faq .instructions__wrapper").on("click", ".instructions__nav-item", function () {
    $(".instructions.faq").find(".active").removeClass("active");
    $(this).addClass("active")
    $(".instructions__main").eq($(this).index()).addClass("active")
  })
});

$(document).ready(function() {
  if($(window).width() < 576) {
    $(".instructions.faq .instructions__nav-item").click(function() {
      $("body,html").animate(
        {
          scrollTop: $(".instructions.faq .instructions__main.active").offset().top - (-10)
        },
        900 //speed
      );
    });
  }
});

$(document).ready(function() {
  if($(window).width() < 992) {
    $(window).scroll(function() {
      if ($(this).scrollTop() > 155){  
          $('body').addClass("sticky");
      }
      else{
          $('body').removeClass("sticky");
      }
    });
  }
});

var $btnTop = $(".back_To_Top")

$(window).on('scroll', function() {
  if ($(this).scrollTop() > $('header').height() + $('.content1').height()) {
   $btnTop.fadeIn(100);
  } else {
   $btnTop.fadeOut(100);
  }
 });
 
 /* ARROW SCROLL */
 $btnTop.on('click', function() {
  $('html, body').animate({
   scrollTop: 0
  }, 700);
 });﻿

$(document).ready(function (){
  /*табы на js*/
  $(".catalog__main.apps").on("click", ".catalog__applications-buttons label", function () {
    /*удалаем классы active*/
    $(".catalog__main.apps").find(".active").removeClass("active");
    /*добавляем класс active */
    $(this).addClass("active")
    $(".applications__list").eq($(this).index()).addClass("active")
  })
});

$(window).scroll(function() {
    if ($(this).scrollTop() > 158){  
        $('.product-fixed').addClass("sticky");
    }
    else{
        $('.product-fixed').removeClass("sticky");
    }
});

$(window).scroll(function() {
    if ($(this).scrollTop() > $('body').height()*0.35){  
        $('.product-fixed').css("display", "none");
        $('.product-fixed').removeClass('show');
    }
    else{
        $('.product-fixed').css("display", "");
        $('.product-fixed').addClass('show');
    }
});

/**
 * This jQuery plugin displays pagination links inside the selected elements.
 *
 * @author Gabriel Birke (birke *at* d-scribe *dot* de)
 * @version 1.2
 * @param {int} maxentries Number of entries to paginate
 * @param {Object} opts Several options (see README for documentation)
 * @return {Object} jQuery Object
 */
 
window._getTimeStampFromStringArr = function _getTimeStampFromStringArr(arr){
  return Math.round(new Date(`${arr[2]}/${arr[1]}/${arr[0]}`).getTime()/1000)
}
window._interpolateString = function _interpolateString(_object, _string){
    for(let key in _object){
    while(_string.includes(`{${key}}`)){
      _string = _string.replace(`{${key}}`, _object[key])
    }
    }
    return _string
}

var x, i, j, selElmnt, a, b, c;
/* Look for any elements with the class "custom-select": */
x = document.getElementsByClassName("custom-select");
for (i = 0; i < x.length; i++) {
  selElmnt = x[i].getElementsByTagName("select")[0];
  /* For each element, create a new DIV that will act as the selected item: */
  a = document.createElement("DIV");
  a.setAttribute("class", "select-selected");
  a.innerHTML = selElmnt.options[selElmnt.selectedIndex].innerHTML;
  x[i].appendChild(a);
  /* For each element, create a new DIV that will contain the option list: */
  b = document.createElement("DIV");
  b.setAttribute("class", "select-items select-hide");
  for (j = 1; j < selElmnt.length; j++) {
    /* For each option in the original select element,
    create a new DIV that will act as an option item: */
    c = document.createElement("DIV");
    c.innerHTML = selElmnt.options[j].innerHTML;
    c.addEventListener("click", function(e) {
        /* When an item is clicked, update the original select box,
        and the selected item: */
        var y, i, k, s, h;
        s = this.parentNode.parentNode.getElementsByTagName("select")[0];
        h = this.parentNode.previousSibling;
        for (i = 0; i < s.length; i++) {
          if (s.options[i].innerHTML == this.innerHTML) {
            s.selectedIndex = i;
            h.innerHTML = this.innerHTML;
            y = this.parentNode.getElementsByClassName("same-as-selected");
            for (k = 0; k < y.length; k++) {
              y[k].removeAttribute("class");
            }
            this.setAttribute("class", "same-as-selected");
            break;
          }
        }
        h.click();
    });
    b.appendChild(c);
  }
  x[i].appendChild(b);
  a.addEventListener("click", function(e) {
    /* When the select box is clicked, close any other select boxes,
    and open/close the current select box: */
    e.stopPropagation();
    closeAllSelect(this);
    this.nextSibling.classList.toggle("select-hide");
    this.classList.toggle("select-arrow-active");
  });
}

function closeAllSelect(elmnt) {
  /* A function that will close all select boxes in the document,
  except the current select box: */
  var x, y, i, arrNo = [];
  x = document.getElementsByClassName("select-items");
  y = document.getElementsByClassName("select-selected");
  for (i = 0; i < y.length; i++) {
    if (elmnt == y[i]) {
      arrNo.push(i)
    } else {
      y[i].classList.remove("select-arrow-active");
    }
  }
  for (i = 0; i < x.length; i++) {
    if (arrNo.indexOf(i)) {
      x[i].classList.add("select-hide");
    }
  }
}

/* If the user clicks anywhere outside the select box,
then close all select boxes: */
document.addEventListener("click", closeAllSelect);

let textElements2 = document.querySelectorAll(".origin");
let targetElements2 = document.querySelectorAll(".target");

textElements2.forEach( (value)=>{
  let dataTarget = value.dataset.target
  let target = document.querySelector(`#${dataTarget}`)
  value.addEventListener( 'click', (e)=>{
    let originTextContent = e.target.textContent
    target.value = originTextContent
  })
})

window._interpolateString = function _interpolateString(_object, _string){
    for(let key in _object){
    while(_string.includes(`{${key}}`)){
      _string = _string.replace(`{${key}}`, _object[key])
    }
    }
    return _string
}

class SearchMenu{
    constructor({searchInput = "search-menu",
                    searchInlineClass = "search-inline",
                    searchOptionsBlockId = "select-search-options",
                    searchOptionsSelectedItem = "same-as-selected",
                    listAllId = "search-input-all",
                    categoriesListId = "search-input-categories",
                    jobsListId = "search-input-jobs",
                    documentsListId = "search-input-documents",
                    juristsListId = "search-input-jurists"}) {
    this.searchInput = searchInput
    this.searchOptionsBlockId = searchOptionsBlockId
    this.searchInlineClass = searchInlineClass
    this.listAllId = listAllId
    this.searchOptionsSelectedItem = searchOptionsSelectedItem
    this.categoriesListId = categoriesListId
    this.jobsListId = jobsListId
    this.documentsListId = documentsListId
    this.juristsListId = juristsListId
        this._initialize()
    }
    _getSearchOptionsBlockId(){
        return document.querySelector(`#${this.searchOptionsBlockId}`)
    }

    _getOptionsSelectedItems(){
        return this._getSearchOptionsBlockId().querySelector(`.${this.searchOptionsSelectedItem}`)
    }

    _getSearchInput(){
        return document.querySelector(`#${this.searchInput}`)
    }

    _getAllSearchInlines(){
        return document.querySelectorAll(`.${this.searchInlineClass}`)
    }

    _getListAllId(){
        return document.querySelector(`#${this.listAllId}`)
    }

    _getCategoriesListId(){
        return document.querySelector(`#${this.categoriesListId}`)
    }

    _getJobsListId(){
        return document.querySelector(`#${this.jobsListId}`)
    }

    _getDocumentsListId(){
        return document.querySelector(`#${this.documentsListId}`)
    }

    _getJuristsListId(){
        return document.querySelector(`#${this.juristsListId}`)
    }
    _getAll(){
        return [this._getListAllId(), this._getCategoriesListId(), this._getJobsListId(), this._getDocumentsListId(), this._getJuristsListId()]
    }
    _hideAll(){
        this._getAll().forEach((value, index) =>{
            value.style.display = "none"
        })
    }
    _initialize(){
        this._getSearchInput().addEventListener("focus", (e)=>{
            // this._getListAllId().style.display = ""
            if(this._getOptionsSelectedItems() === null){
                this._getListAllId().style.display = ""
                return 0
            }
            switch (this._getOptionsSelectedItems().textContent){
                case 'Всё':
                    this._getListAllId().style.display = ""
                    break
                case "Юристы":
                    this._getJuristsListId().style.display = ""
                    break
                case "Задания":
                    this._getJobsListId().style.display = ""
                    break
                case "Документы":
                    this._getDocumentsListId().style.display = ""
                    break
                default:
                    this._getListAllId().style.display = ""
                    break
            }
        })
        this._getAllSearchInlines().forEach((value, key) => {
            // console.log(value)
            value.querySelectorAll("li").forEach((v, k) =>{
                v.addEventListener("click", (e)=>{
                    console.log("event")
                    this._getSearchInput().value = e.target.textContent
                })
            })
        })
        document.addEventListener("click", (e)=>{
            if(!e.target.classList.contains(this.searchInlineClass) && e.target.id !== this.searchInput && !e.target.parentNode.classList.contains(this.searchInlineClass)){
                this._hideAll()
            }
        })
        this._getSearchInput().addEventListener("input", (e)=>{
            this._hideAll()
            if(e.target.value === ""){
                this._getCategoriesListId().style.display = "none"
                return 0
            }
            this._getCategoriesListId().style.display = ""
            this._getCategoriesListId().querySelectorAll("li").forEach((value, key) => {
                value.querySelector("span").textContent = e.target.value

            })
        })
    }

}

// new SearchMenu({})


class SearchMenuExtended{
    constructor(){
        this.cats = []
        this.tasks = []
        this.laws = []
        this.docs = []
        this.picBasePath = ""
        this.resultLawsList = document.querySelector("#result-lawyers ul")
        this.resultTasksList = document.querySelector("#result-tasks ul")
        this.resultCatsList = document.querySelector("#result-cats ul")
        this.resultDocsList = document.querySelector("#result-docs ul")
        this.searchInput = document.querySelector("#site-search")
        this.searchValue = document.querySelector("#site-search").value
        this.searchTip = document.querySelector("#search-tip")
        this.headerResult = document.querySelector("#header-res")
        this.si = this._getSi()
        this._init()
    }

    _getSi(){
        return document.querySelector("#cs1").querySelector(".select-items").querySelector(".same-as-selected")
    }

    _getSelectBlockItems(){
      return document.querySelector("#cs1").querySelector(".select-items")
    }
    /**
     * Участвует в кэшировании результатов.
     *
     * Принимает колбек, который должен возвращать кол-во записей о Юристах в БД.
     *
     * Если колбек не передан, по умолчанию возвращает 5
     *
     *
     * @param {function} cb
     * @returns {number} Number
     */
    _returnLawsEntriesCount(cb){
        if(!cb){
            return 5
        } else{
            return cb()
        }
    }
    _returnTasksCount(cb){
        if(!cb){
            return 3
        }else{
            return cb()
        }
    }
    _returnDocsCount(cb){
        if(!cb){
            return 3
        }else{
            return cb()
        }
    }
    _nodeIsContain(node, element){
      let r = false
      if(node.childElementCount > 0){
        node.querySelectorAll("*").forEach((v,k,a)=>{
          if(v == element){
            r = true
          }
        })
      }
      return r
    }

    _init(){
      document.querySelectorAll(".header__search *").forEach((v,k,a)=>{
        v.classList.add("click__exclude")
      })
      document.querySelector(".header__search").classList.add("click__exclude")
      document.body.addEventListener("click", (e)=>{         
      if(e.target.parentNode.classList.contains("click__exclude") || this._nodeIsContain(document.querySelector(".header__search"), e.target)){
      }else{
        
        this.headerResult.style.display = "none"
        document.querySelector(".header__search-tip").style.display = "none"
            console.log(e)
            console.log(this._nodeIsContain(document.querySelector(".header__search"), e.target))
            console.log("second Iff")
      }
      })
      this._getSelectBlockItems().querySelectorAll('div').forEach((v,k,a)=>{
        let subBlocks = [this.resultLawsList.parentNode,this.resultTasksList.parentNode, this.resultCatsList.parentNode, this.resultDocsList.parentNode]
        v.addEventListener('click', (e)=>{
          let target = e.target
          if(target.innerHTML === "Категории"){
            subBlocks.forEach((item, index, arr)=>{
              item.style.display = "none"
            })
            this.FilterCat()
          }else if(target.innerHTML === "Блоги"){
            subBlocks.forEach((item, index, arr)=>{
              item.style.display = "none"
            })
            this.FilterTasks()
          }else if(target.innerHTML === "Документы"){
            subBlocks.forEach((item, index, arr)=>{
              item.style.display = "none"
            })
            this.FilterDocs()
          }else{
            this.FilterCat()
                this.FilterLaw()
                this.FilterTasks()
                this.FilterDocs()
          }
        })
      })
        this.searchInput.addEventListener("click", (e)=>{
          let _input = new Event('input')
          this.searchInput.dispatchEvent(_input)
            this.searchTip.style.display = ""
            if(!this.headerResult.classList.contains("active")){
                this.headerResult.style.display = "none"
                this.headerResult.classList.remove("active")
            }else{
                this.searchTip.style.display = "none"
            }
        })
        this.searchTip.querySelectorAll("li").forEach((v,k,a)=>{
            v.addEventListener("click", (e)=>{
                this.searchInput.value = e.target.innerHTML
                let event = new Event("input")
                this.searchInput.dispatchEvent(event)
            })
        })
        this.searchInput.addEventListener("click", (e)=>{
          this.searchTip.style.display = ""
          if(!this.headerResult.classList.contains("active")){
              this.headerResult.style.display = "none"
              this.headerResult.classList.remove("active")
          }else{
              this.searchTip.style.display = "none"
          }
        })
        this.searchInput.addEventListener("input", async (e)=>{
            if(this.searchInput.value.length > 2){
                this.headerResult.style.display = ""
                this.headerResult.classList.add("active")
                this.searchTip.style.display = "none"
            }
            if(this.searchInput.value.length < 3){
                this.headerResult.style.display = "none"
                this.headerResult.classList.remove("active")
            }
            if(this.cats.length < 1){
               await this.FetchCat("https://yurhub.com/search/categories", this.cats)
            }
            if(this._returnLawsEntriesCount() !== this.laws.length){
               this.laws.splice(0, this._returnLawsEntriesCount()+1)
               await this.FetchCat("https://yurhub.com/lawyers.php", this.laws)
            }
            if(this._returnTasksCount() !== this.tasks.length){
                this.FetchCat("https://yurhub.com/search/blogs", this.tasks)
            }
            if(this._returnDocsCount() !== this.docs.length){
                await this.FetchCat("https://yurhub.com/search/documents", this.docs)
            }
            if(this._getSi() && this._getSi().innerHTML === "Категории"){
                this.headerResult.style.display = "none"
                this.headerResult.classList.remove("active")
                this.FilterCat()
            }else if(this._getSi() && this._getSi().innerHTML === "Блоги"){
                this.headerResult.style.display = "none"
                this.headerResult.classList.remove("active")
                this.FilterTasks()
            }else if(this._getSi() && this._getSi().innerHTML === "Документы"){
                this.headerResult.style.display = "none"
                this.headerResult.classList.remove("active")
                this.FilterDocs()
            }else{
                this.FilterCat()
                this.FilterLaw()
                this.FilterTasks()
                this.FilterDocs()
            }
        })
    }

   async FetchCat(url, arr){
        let response = await fetch(url, {
        cache: 'force-cache',
      })
        if(response.ok){
            let json = await response.json()
            arr.splice(0, arr.length)
            json.forEach((v)=>{
                if(arr.indexOf(v.name) === -1){
                    arr.push(v)
                }
            })
            return json
        }else{
            alert(`HTTP Error: ${response.status}`)
            return false
        }

    }

    _arrCont(arr, cb){
        arr.forEach((v,k,a)=>{
            if(v.name.toLowerCase().indexOf(this.searchInput.value.toLowerCase()) !== -1 && this.searchInput.value !== "" && this.searchInput.value.length > 2){
                cb(v)
            }
        })
    }

    FilterCat(){
        this.dummyHTMLForCats = '<h5><a href="{link}">{value} <span>в категории {name}</span></a></h5>'
        this.resultCatsList.innerHTML = "<span class='tip'>Ничего не найдено</span>"
        this.resultCatsList.parentNode.style.display = "none"
        if(this.searchInput.value.length > 2){
            this.cats.forEach((v,k,a)=>{
                v.subtypes.forEach((val,key,arr)=>{
                    if(val.toLowerCase().indexOf( this.searchInput.value.toLowerCase() ) !== -1 && this.searchInput.value !== "" ){
                        this.headerResult.style.display = ""
                        this.headerResult.classList.add("active")
                        this.resultCatsList.parentNode.style.display = ""
                        let newCatItem = document.createElement("li")
                        let catItemData = {
                            "link":v.link,
                            "value": val,
                            "name": v.name
                        }
                        let spantip = this.resultCatsList.querySelector("span.tip")
                        if(spantip){
                            spantip.outerHTML = ""
                        }
                        newCatItem.innerHTML = _interpolateString(catItemData, this.dummyHTMLForCats)
                        this.resultCatsList.insertAdjacentElement("beforeend", newCatItem)
                    }
                })
            })
        }
    }

    FilterLaw(){
        this.dummyHTMLForLaws = '<img src="{picBasePath}/{picPath}" alt="search-item"><div class="header__result-item"><h5 class="header__result-title"> <a href="{link}">{lawName}</a></h5></div>'
        console.log(this.laws)
        let pCB = this.picBasePath
        this.resultLawsList.innerHTML = "<span>Ничего не найдено</span>"
        this.resultLawsList.parentNode.style.display = "none"
        this._arrCont(this.laws, (v)=>{
            this.resultLawsList.parentNode.style.display = ""
            this.headerResult.style.display = ""
            this.headerResult.classList.add("active")
            let newLawItem = document.createElement("li")
            let lawData = {
                "picBasePath": pCB,
                "picPath": v.pic_path,
                "lawName": v.name,
                "link": v.link
            }
            if(this.resultLawsList.querySelector("span")){
                this.resultLawsList.querySelector("span").outerHTML = ""
            }
            newLawItem.innerHTML = _interpolateString(lawData, this.dummyHTMLForLaws)
            this.resultLawsList.insertAdjacentElement("beforeend", newLawItem)
        })
    }

    FilterTasks(){
        // console.log(this.tasks)
        this.resultTasksList.innerHTML = "<span>Ничего не найдено</span>"
        this.resultTasksList.parentNode.style.display = "none"
        this._arrCont(this.tasks, (v)=>{
            this.resultTasksList.parentNode.style.display = ""
            this.headerResult.style.display = ""
            this.headerResult.classList.add("active")
            this.dummyHTMLForTasks = '<h5><a href="{link}">{name}</a></h5>'
            let taskItem = document.createElement("li")
            let taskItemData = {
                "link": v.link,
                "name": v.name
            }
            let spantip = this.resultTasksList.querySelector("span")
            if(spantip){
                spantip.outerHTML = ""
            }
            taskItem.innerHTML = _interpolateString(taskItemData, this.dummyHTMLForTasks)
            this.resultTasksList.insertAdjacentElement("beforeend", taskItem)
        })
    }

    FilterDocs(){
        this.resultDocsList.innerHTML = ""
        this.resultDocsList.parentNode.style.display = "none"
        this._arrCont(this.docs, (v)=>{
            console.log(v)
            this.resultDocsList.parentNode.style.display = ""
            this.headerResult.style.display = ""
            this.headerResult.classList.add("active")
            this.dummyHTMLForDocs = '<img src="{previewImg}" alt="search-item"><div class="header__result-item"><h5 class="header__result-title"> <a href="{link}">{name}</a></h5><p>{price}</p></div>'
            let newFilterItem = document.createElement("li")
            let FilterItemData = {
                "picBasePath":this.picBasePath,
                "previewImg": v.preview_img,
                "link": v.link,
                "name": v.name,
                "price": v.price == "беслпатно" ? "бесплатно" : v.price
            }
            newFilterItem.innerHTML = _interpolateString(FilterItemData, this.dummyHTMLForDocs)
            this.resultDocsList.insertAdjacentElement("beforeend", newFilterItem)
        })
    }
}

let sme = new SearchMenuExtended()

function countChar(val) {
  var len = val.value.length;
  if (len >= 500) {
    val.value = val.value.substring(0, 482);
  } else {
    $('#charNum').text(482 - len);
  }
};

(function($) {
  var CheckboxDropdown = function(el) {
    var _this = this;
    this.isOpen = false;
    this.areAllChecked = false;
    this.$el = $(el);
    this.$label = this.$el.find('.dropdown-label');
    this.$checkAll = this.$el.find('[data-toggle="check-all"]').first();
    this.$inputs = this.$el.find('[type="checkbox"]');
    
    this.onCheckBox();
    
    this.$label.on('click', function(e) {
      e.preventDefault();
      _this.toggleOpen();
    });
    
    this.$checkAll.on('click', function(e) {
      e.preventDefault();
      _this.onCheckAll();
    });
    
    this.$inputs.on('change', function(e) {
      _this.onCheckBox();
    });
  };
  
  CheckboxDropdown.prototype.onCheckBox = function() {
    this.updateStatus();
  };
  
  CheckboxDropdown.prototype.updateStatus = function() {
    var checked = this.$el.find(':checked');
    
    this.areAllChecked = false;
    this.$checkAll.html('');
    
    if(checked.length <= 0) {

    }
    else if(checked.length === 1) {

    }
    else if(checked.length === this.$inputs.length) {
      this.$label.html('');
      this.areAllChecked = true;
      this.$checkAll.html('');
    }
    else {
      this.$label.html(checked.length + ' выбрано');
    }
  };
  
  CheckboxDropdown.prototype.onCheckAll = function(checkAll) {
    if(!this.areAllChecked || checkAll) {
      this.areAllChecked = true;
      this.$checkAll.html('Uncheck All');
      this.$inputs.prop('checked', true);
    }
    else {
      this.areAllChecked = false;
      this.$checkAll.html('Check All');
      this.$inputs.prop('checked', false);
    }
    
    this.updateStatus();
  };
  
  CheckboxDropdown.prototype.toggleOpen = function(forceOpen) {
    var _this = this;
    
    if(!this.isOpen || forceOpen) {
       this.isOpen = true;
       this.$el.addClass('on');
      $(document).on('click', function(e) {
        if(!$(e.target).closest('[data-control]').length) {
         _this.toggleOpen();
        }
      });
    }
    else {
      this.isOpen = false;
      this.$el.removeClass('on');
      $(document).off('click');
    }
  };
  
  var checkboxesDropdowns = document.querySelectorAll('[data-control="checkbox-dropdown"]');
  for(var i = 0, length = checkboxesDropdowns.length; i < length; i++) {
    new CheckboxDropdown(checkboxesDropdowns[i]);
  }
})(jQuery);

function getPasteEvent() {
  var el = document.createElement('input'),
      name = 'onpaste';
  el.setAttribute(name, '');
  return (typeof el[name] === 'function')?'paste':'input';             
}

var pasteEventName = getPasteEvent() + ".mask",
ua = navigator.userAgent,
iPhone = /iphone/i.test(ua),
android=/android/i.test(ua),
caretTimeoutId;

$.mask = {
//Predefined character definitions
definitions: {
  '9': "[0-9]",
  'a': "[A-Za-z]",
  '*': "[A-Za-z0-9]"
},
dataName: "rawMaskFn",
placeholder: '_',
};

$.fn.extend({
//Helper Function for Caret positioning
caret: function(begin, end) {
  var range;

  if (this.length === 0 || this.is(":hidden")) {
    return;
  }

  if (typeof begin == 'number') {
    end = (typeof end === 'number') ? end : begin;
    return this.each(function() {
      if (this.setSelectionRange) {
        this.setSelectionRange(begin, end);
      } else if (this.createTextRange) {
        range = this.createTextRange();
        range.collapse(true);
        range.moveEnd('character', end);
        range.moveStart('character', begin);
        range.select();
      }
    });
  } else {
    if (this[0].setSelectionRange) {
      begin = this[0].selectionStart;
      end = this[0].selectionEnd;
    } else if (document.selection && document.selection.createRange) {
      range = document.selection.createRange();
      begin = 0 - range.duplicate().moveStart('character', -100000);
      end = begin + range.text.length;
    }
    return { begin: begin, end: end };
  }
},
unmask: function() {
  return this.trigger("unmask");
},
mask: function(mask, settings) {
  var input,
    defs,
    tests,
    partialPosition,
    firstNonMaskPos,
    len;

  if (!mask && this.length > 0) {
    input = $(this[0]);
    return input.data($.mask.dataName)();
  }
  settings = $.extend({
    placeholder: $.mask.placeholder, // Load default placeholder
    completed: null
  }, settings);


  defs = $.mask.definitions;
  tests = [];
  partialPosition = len = mask.length;
  firstNonMaskPos = null;

  $.each(mask.split(""), function(i, c) {
    if (c == '?') {
      len--;
      partialPosition = i;
    } else if (defs[c]) {
      tests.push(new RegExp(defs[c]));
      if (firstNonMaskPos === null) {
        firstNonMaskPos = tests.length - 1;
      }
    } else {
      tests.push(null);
    }
  });

  return this.trigger("unmask").each(function() {
    var input = $(this),
      buffer = $.map(
      mask.split(""),
      function(c, i) {
        if (c != '?') {
          return defs[c] ? settings.placeholder : c;
        }
      }),
      focusText = input.val();

    function seekNext(pos) {
      while (++pos < len && !tests[pos]);
      return pos;
    }

    function seekPrev(pos) {
      while (--pos >= 0 && !tests[pos]);
      return pos;
    }

    function shiftL(begin,end) {
      var i,
        j;

      if (begin<0) {
        return;
      }

      for (i = begin, j = seekNext(end); i < len; i++) {
        if (tests[i]) {
          if (j < len && tests[i].test(buffer[j])) {
            buffer[i] = buffer[j];
            buffer[j] = settings.placeholder;
          } else {
            break;
          }

          j = seekNext(j);
        }
      }
      writeBuffer();
      input.caret(Math.max(firstNonMaskPos, begin));
    }

    function shiftR(pos) {
      var i,
        c,
        j,
        t;

      for (i = pos, c = settings.placeholder; i < len; i++) {
        if (tests[i]) {
          j = seekNext(i);
          t = buffer[i];
          buffer[i] = c;
          if (j < len && tests[j].test(t)) {
            c = t;
          } else {
            break;
          }
        }
      }
    }

    function keydownEvent(e) {
      var k = e.which,
        pos,
        begin,
        end;

      //backspace, delete, and escape get special treatment
      if (k === 8 || k === 46 || (iPhone && k === 127)) {
        pos = input.caret();
        begin = pos.begin;
        end = pos.end;

        if (end - begin === 0) {
          begin=k!==46?seekPrev(begin):(end=seekNext(begin-1));
          end=k===46?seekNext(end):end;
        }
        clearBuffer(begin, end);
        shiftL(begin, end - 1);

        e.preventDefault();
      } else if (k == 27) {//escape
        input.val(focusText);
        input.caret(0, checkVal());
        e.preventDefault();
      }
    }

    function keypressEvent(e) {
      var k = e.which,
        pos = input.caret(),
        p,
        c,
        next;

      if (e.ctrlKey || e.altKey || e.metaKey || k < 32) {//Ignore
        return;
      } else if (k) {
        if (pos.end - pos.begin !== 0){
          clearBuffer(pos.begin, pos.end);
          shiftL(pos.begin, pos.end-1);
        }

        p = seekNext(pos.begin - 1);
        if (p < len) {
          c = String.fromCharCode(k);
          if (tests[p].test(c)) {
            shiftR(p);

            buffer[p] = c;
            writeBuffer();
            next = seekNext(p);

            if(android){
              setTimeout($.proxy($.fn.caret,input,next),0);
            }else{
              input.caret(next);
            }

            if (settings.completed && next >= len) {
              settings.completed.call(input);
            }
          }
        }
        e.preventDefault();
      }
    }

    function clearBuffer(start, end) {
      var i;
      for (i = start; i < end && i < len; i++) {
        if (tests[i]) {
          buffer[i] = settings.placeholder;
        }
      }
    }

    function writeBuffer() { input.val(buffer.join('')); }

    function checkVal(allow) {
      //try to place characters where they belong
      var test = input.val(),
        lastMatch = -1,
        i,
        c;

      for (i = 0, pos = 0; i < len; i++) {
        if (tests[i]) {
          buffer[i] = settings.placeholder;
          while (pos++ < test.length) {
            c = test.charAt(pos - 1);
            if (tests[i].test(c)) {
              buffer[i] = c;
              lastMatch = i;
              break;
            }
          }
          if (pos > test.length) {
            break;
          }
        } else if (buffer[i] === test.charAt(pos) && i !== partialPosition) {
          pos++;
          lastMatch = i;
        }
      }
      if (allow) {
        writeBuffer();
      } else if (lastMatch + 1 < partialPosition) {
        input.val("");
        clearBuffer(0, len);
      } else {
        writeBuffer();
        input.val(input.val().substring(0, lastMatch + 1));
      }
      return (partialPosition ? i : firstNonMaskPos);
    }

    input.data($.mask.dataName,function(){
      return $.map(buffer, function(c, i) {
        return tests[i]&&c!=settings.placeholder ? c : null;
      }).join('');
    });

    if (!input.attr("readonly"))
      input
      .one("unmask", function() {
        input
          .unbind(".mask")
          .removeData($.mask.dataName);
      })
      .bind("focus.mask", function() {
        clearTimeout(caretTimeoutId);
        var pos,
          moveCaret;

        focusText = input.val();
        pos = checkVal();
        
        caretTimeoutId = setTimeout(function(){
          writeBuffer();
          if (pos == mask.length) {
            input.caret(0, pos);
          } else {
            input.caret(pos);
          }
        }, 10);
      })
      .bind("blur.mask", function() {
        checkVal();
        if (input.val() != focusText)
          input.change();
      })
      .bind("keydown.mask", keydownEvent)
      .bind("keypress.mask", keypressEvent)
      .bind(pasteEventName, function() {
        setTimeout(function() { 
          var pos=checkVal(true);
          input.caret(pos); 
          if (settings.completed && pos == input.val().length)
            settings.completed.call(input);
        }, 0);
      });
    checkVal(); //Perform initial check for existing values
  });
}
});

$(".phone-mask").mask("+380(99)999-99-99");
